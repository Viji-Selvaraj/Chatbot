function chatbotInit() {
  var div = document.createElement("div");
  document.getElementsByTagName('body')[0].appendChild(div);
  div.outerHTML = "<div id='botDiv' style='height: 38px; box-shadow:0 5px 15px rgba(0,0,0,0.4); position: fixed; bottom: 0; right:35px; background-color: #1a64db'><div id='botTitleBar' style='height: 38px; width: 400px;color: #FFF;background: -webkit-linear-gradient(#FFF, #FFF); -webkit-background-clip: text;-webkit-text-fill-color: transparent; padding: 10px; position:fixed; cursor: pointer;'>SimplyBlu Assistant (Chat Now)</div><iframe name='myiframe'></iframe><form class='message-box' id='mymsg' method='POST' target='myiframe'><input type='text' id='MSG' name='MSG' class='message-input' placeholder='Type message...' ><i class='fas fa-microphone' id='start-record-btn'></i><button type='submit' class='message-submit'>Send</button></form></div>";
  document.getElementById('botTitleBar').addEventListener('click', function (e) {
      e.target.matches = e.target.matches || e.target.msMatchesSelector;
      if (e.target.matches('#botTitleBar')) {
          var botDiv = document.querySelector('#botDiv');
          botDiv.style.height = botDiv.style.height == '600px' ? '38px' : '600px';
      };
  });
}


document.addEventListener("DOMContentLoaded", function() {
  chatbotInit()
});
