var $messages = $('.messages-content');
var serverResponse = "wala";
var button_val = ""
var str_res = ""
var pos = 1

var suggession;
//speech reco
try {
  var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  var recognition = new SpeechRecognition();
}
catch(e) {
  console.error(e);
  $('.no-browser-support').show();
}

$('#start-record-btn').on('click', function(e) {
  recognition.start();
});

recognition.onresult = (event) => {
  const speechToText = event.results[0][0].transcript;
 document.getElementById("MSG").value= speechToText;
  //console.log(speechToText)
  insertMessage()
}


function listendom(no){
  console.log(no)
  //console.log(document.getElementById(no))
document.getElementById("MSG").value= no.innerHTML;
  insertMessage();
}

$(window).load(function() {
  $messages.mCustomScrollbar();
  setTimeout(function() {
    serverMessage("hello i am Standard Bank Merchant Digital Assistant, say hi and i will show you quick buttions");
  }, 100);

});

function updateScrollbar() {
  $messages.mCustomScrollbar("update").mCustomScrollbar('scrollTo', 'bottom', {
    scrollInertia: 10,
    timeout: 0
  });
}



function insertMessage(inp_val) {
  msg = $('.message-input').val();
  if ($.trim(msg) == '') {
    return false;
  }
  $('<div class="message message-personal">' + msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
  fetchmsg(2)

  $('.message-input').val(null);
  updateScrollbar();

}

function insertMessage1(inp_val) {
  msg = inp_val;
  button_val = inp_val;
  if ($.trim(msg) == '') {
    return false;
  }
  $('<div class="message message-personal">' + msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
  fetchmsg(1)
}

document.getElementById("mymsg").onsubmit = (e)=>{
  e.preventDefault()
  insertMessage();
  // serverMessage("hello");
  // speechSynthesis.speak( new SpeechSynthesisUtterance("hello"))
}

function serverMessage(response2) {


  if ($('.message-input').val() != '') {
    return false;
  }
  $('<div class="message loading new"><figure class="avatar"><img src="css/bot.png" /></figure><span></span></div>').appendTo($('.mCSB_container'));
  updateScrollbar();


  setTimeout(function() {
    $('.message.loading').remove();
    $('<div class="message new"><figure class="avatar"><img src="css/bot.png" /></figure>' + response2 + '</div>').appendTo($('.mCSB_container')).addClass('new');
    updateScrollbar();
  }, 100 + (Math.random() * 20) * 100);

}



function fetchmsg(butt){

     var url = 'http://localhost:5000/send-msg';

      const data = new URLSearchParams();
      if (butt == 2){
        for (const pair of new FormData(document.getElementById("mymsg"))) {
            data.append(pair[0], pair[1]);
        }
      }else{
        data.append('MSG', button_val);
      }


      console.log("abc",data)
        fetch(url, {
          method: 'POST',
          body:data
        }).then(res => res.json())
         .then(response => {
          console.log("response", response);

         var str_array = response.Reply.split(',');
         str_res = str_array[0]
         if (response.Reply.includes('CR-')){
           str_res = str_res + "<div class=\"carousel-container w-100\"><div id=\"carouselContent\" class=\"carousel slide\" data-ride=\"carousel\" data-interval=\"false\"><div class=\"carousel-inner\" role=\"listbox\"><div class=\"carousel-item active text-center p-4\"> <p>" + str_array[1].slice(3)  + "</p> </div>"
           pos = 2
         }else if (response.Reply.includes('LK-')){
            str_res = str_res + "<div class=\"card text-white bg-secondary mb-3\" style=\"max-width: 18rem;\"><img class=\"card-img-top\" src=\"https://www.standardbank.com/pages/StandardBankGroup/web/images/LOGO_CIB-logo.jpg\" alt=\"Card image cap\"><div class=\"card-body\"><h5 class=\"card-title\">Card Type</h5><p class=\"card-text\">"+ str_array  + "</p><a href=\"https://en.wikipedia.org/wiki/Standard_Bank\" target=\"_blank\" class=\"btn text-white btn-secondary\">Goto Link</a></div></div>"
         }
         for(var i = pos; i < str_array.length; i++) {
            str_array[i] = str_array[i].replace(/^\s*/, "").replace(/\s*$/, "");
            if (str_array[i].includes('BT-')) {
               str_res = str_res + "<br><input type=\"button\" class=\"btn\" value='"+ str_array[i].slice(3) +"' onclick=\"insertMessage1('"+str_array[i].slice(3)+"')\">"
           		//console.log(str_res);
         		} else if (str_array[i].includes('CR-')){
              console.log("value of i - ",i);
              str_res = str_res + "<div class=\"carousel-item text-center p-4\"> <p>" + str_array[i].slice(3) + "</p> </div>"
            }
            //else if (str_array[i].includes('LK-')){

            //}
         }
         if (response.Reply.includes('CR-')){
         str_res = str_res + "</div><a class=\"carousel-control-prev\" href=\"#carouselContent\" role=\"button\" data-slide=\"prev\"><span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span><span class=\"sr-only\">Previous</span></a><a class=\"carousel-control-next\" href=\"#carouselContent\" role=\"button\" data-slide=\"next\"><span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span><span class=\"sr-only\">Next</span></a></div></div>"
}
         console.log(str_res);
         //serverMessage(response.Reply);
         serverMessage(str_res);
          //speechSynthesis.speak( new SpeechSynthesisUtterance(response.Reply))


         })
          .catch(error => console.error('Error h:', error));

}

$(function() {
  $("#chat-circle").click(function() {
    $("#chat-circle").toggle('scale');
    $(".chat-box").toggle('scale');
  })

  $(".chat-box-toggle").click(function() {
    $("#chat-circle").toggle('scale');
    $(".chat-box").toggle('scale');
  })

})
